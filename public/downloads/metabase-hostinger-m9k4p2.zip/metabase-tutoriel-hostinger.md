# Tutoriel : Préparer ton VPS Hostinger pour installer Metabase avec l'IA

Ce guide couvre **tout ce que tu fais toi-même**, avant de laisser l'IA prendre le relais.

À la fin, tu auras :
1. Un VPS Hostinger opérationnel (KVM 2)
2. Toutes les informations à copier-coller dans le fichier destiné à l'IA
3. (Optionnel) Un nom de domaine pointant vers ton serveur

---

## Étape 1 — Commander le VPS sur Hostinger

👉 **Lien** : https://www.hostinger.fr/jeremy10
🎟️ **Coupon** : `JEREMY10` (à entrer au moment du paiement pour la réduction)

1. Ouvre le lien ci-dessus.
2. Choisis le plan **KVM 2** (2 vCPU, 8 Go RAM, 100 Go NVMe). C'est le bon équilibre pour Metabase : Metabase est gourmand en RAM, et 8 Go évitent les plantages.
3. Choisis la durée d'abonnement (plus c'est long, moins c'est cher au mois).
4. Entre le coupon **`JEREMY10`** pour la réduction, puis paye.

> **Pourquoi KVM 2 et pas KVM 1 ?** Metabase tourne sur la JVM (Java) et consomme facilement 1 à 2 Go de RAM au repos. Avec 4 Go (KVM 1), tu es à l'étroit dès que la base grossit. 8 Go = tranquille.

---

## Étape 2 — Configurer le système d'exploitation

Une fois le VPS acheté, Hostinger te demande de le configurer :

1. Dans le panneau Hostinger (hPanel), va dans **VPS → ton serveur**.
2. **Système d'exploitation** : choisis **Ubuntu 24.04 LTS** (image "OS pur", PAS un template avec un panel type CyberPanel/CloudPanel — on veut une machine propre).
3. Définis un **mot de passe root** solide et **note-le** (tu vas en avoir besoin).
4. Attends que le serveur passe en statut **"En cours d'exécution" / "Running"**.

---

## Étape 3 — Récupérer les informations du serveur

Dans hPanel, sur la page de ton VPS, note les infos suivantes. **Ce sont elles que tu donneras à l'IA.**

| Information | Où la trouver | Exemple |
|---|---|---|
| **Adresse IP** | Page VPS → "Adresse IP" | `82.123.45.67` |
| **Utilisateur SSH** | Toujours `root` par défaut | `root` |
| **Mot de passe root** | Celui que tu as défini à l'étape 2 | (le tien) |
| **Port SSH** | `22` par défaut | `22` |
| **OS installé** | Page VPS → "Système d'exploitation" | `Ubuntu 24.04` |

> ⚠️ **Sécurité** : ce mot de passe root donne un accès total à ton serveur. Ne le mets pas dans un fichier public, un dépôt Git, ou une vidéo. Tu le copies uniquement dans ta conversation privée avec l'IA.

---

## Étape 4 — Se connecter au serveur en SSH

Tu peux laisser l'IA le faire, mais teste d'abord toi-même que la connexion marche.

**Sur Mac / Linux** — ouvre le Terminal :
```bash
ssh root@82.123.45.67
```
(remplace par ton IP)

**Sur Windows** — utilise le Terminal Windows (ou PowerShell), même commande.

- La première fois, il demande de confirmer l'empreinte → tape `yes`.
- Entre le mot de passe root (rien ne s'affiche pendant que tu tapes, c'est normal).
- Si tu vois un prompt du type `root@srv123:~#`, tu es connecté. 🎉

> 💡 **Astuce confort** : dans ta conversation avec l'IA, tu peux taper `! ssh root@ton-ip` pour que la commande s'exécute directement et que l'IA voie la sortie.

---

## Étape 5 (Optionnel mais recommandé) — Un nom de domaine

Metabase est utilisable directement via `http://ton-ip:3000`, mais c'est mieux d'avoir une adresse propre en HTTPS, du type `https://metabase.ton-domaine.com`.

1. Achète un domaine (Hostinger en propose, ou n'importe quel registrar).
2. Dans la zone DNS du domaine, crée un enregistrement **A** :
   - **Type** : `A`
   - **Nom / Hôte** : `metabase` (ça donnera `metabase.ton-domaine.com`)
   - **Valeur / Pointe vers** : l'**adresse IP** de ton VPS
   - **TTL** : laisse par défaut
3. Attends la propagation DNS (quelques minutes à quelques heures).

> Si tu fais ça, ajoute le sous-domaine choisi (`metabase.ton-domaine.com`) à la liste des infos de l'étape 3. L'IA s'occupera du certificat HTTPS automatiquement.

---

## Étape 6 — Passer le relais à l'IA

Tu as maintenant tout ce qu'il faut. Il ne te reste qu'à :

1. Ouvrir ta conversation avec l'IA (Claude Code, ou l'agent de ton choix).
2. Lui envoyer le fichier **`metabase-prompt-ia.md`**.
3. Compléter en haut du fichier les informations que tu viens de récupérer (IP, mot de passe, domaine).
4. Laisser l'IA dérouler l'installation. Elle va se connecter en SSH, installer Docker, lancer Metabase + sa base de données, sécuriser le serveur et (si tu as un domaine) mettre le HTTPS.

---

## Récapitulatif des infos à préparer

Avant d'appeler l'IA, coche que tu as bien :

- [ ] Adresse IP du VPS
- [ ] Utilisateur SSH (`root`)
- [ ] Mot de passe root
- [ ] Port SSH (`22`)
- [ ] OS = Ubuntu 24.04 LTS
- [ ] (Optionnel) Sous-domaine pointant vers l'IP en enregistrement A

Une fois ces cases cochées → direction le fichier `metabase-prompt-ia.md`.
