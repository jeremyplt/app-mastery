# Mission : Installer Metabase sur mon VPS Hostinger

Tu es un ingénieur DevOps expérimenté. Ton objectif : installer et sécuriser **Metabase** (outil de business intelligence open-source) sur mon VPS Hostinger, en Docker, avec une base de données PostgreSQL dédiée, et le rendre accessible en HTTPS si un domaine est fourni.

Procède **méthodiquement, une étape à la fois**. Après chaque commande importante, vérifie le résultat avant de continuer. Explique-moi ce que tu fais au fur et à mesure (je suis débutant/intermédiaire et je veux comprendre).

---

## 🔑 Mes informations (à compléter AVANT d'envoyer à l'IA)

```
Adresse IP du VPS   : TON_ADRESSE_IP
Utilisateur SSH     : root
Mot de passe root   : TON_MOT_DE_PASSE
Port SSH            : 22
OS                  : Ubuntu 24.04 LTS
```

> Si le champ "Domaine" est vide, expose Metabase directement sur le port 3000 et ne configure PAS de HTTPS. Si un domaine est fourni, configure un reverse proxy avec HTTPS automatique.

---

## Contexte technique

- Le VPS est un **Hostinger KVM 2** : 2 vCPU, 8 Go RAM, 100 Go NVMe, Ubuntu 24.04 fraîchement installé (aucun logiciel préinstallé).
- Je veux une installation **propre, reproductible et durable**, pas un bricolage.
- Tout doit tourner en **conteneurs Docker** orchestrés par **docker compose**, pour pouvoir sauvegarder/redémarrer/mettre à jour facilement.

---

## Étapes à réaliser

### 1. Connexion et état des lieux
- Connecte-toi en SSH avec les informations ci-dessus.
- Vérifie l'OS (`lsb_release -a`), la RAM (`free -h`), le disque (`df -h`).
- Mets à jour le système : `apt update && apt upgrade -y`.

### 2. Sécurité de base du serveur (IMPORTANT — fais-le avant d'exposer quoi que ce soit)
- Crée un **utilisateur non-root** avec accès sudo (l'usage de root en direct est à éviter).
- Configure le **pare-feu UFW** : autorise uniquement SSH (22), HTTP (80) et HTTPS (443). Bloque le reste. Si pas de domaine, autorise aussi le port 3000.
- Installe et active **fail2ban** pour protéger SSH du brute-force.
- **Ajoute un fichier de swap de 2 Go** : Metabase (JVM) peut consommer beaucoup de RAM, et un pic sans swap fait planter le serveur (kill OOM). C'est une protection indispensable.

### 3. Installation de Docker
- Installe **Docker Engine** et le plugin **docker compose** via le dépôt officiel Docker (pas la version obsolète d'apt).
- Ajoute l'utilisateur non-root au groupe `docker`.
- Vérifie : `docker --version` et `docker compose version`.

### 4. Déploiement de Metabase + PostgreSQL
- Crée un dossier de travail, ex : `/opt/metabase`.
- Écris un fichier `docker-compose.yml` avec **deux services** :
  - **postgres** : base de données qui stocke la configuration de Metabase (utilisateurs, dashboards, questions). Image officielle `postgres`, avec un **volume nommé** pour la persistance des données, et un mot de passe fort (génère-le et donne-le-moi).
  - **metabase** : image officielle `metabase/metabase:latest`, configurée pour utiliser le Postgres ci-dessus comme base d'application (variables `MB_DB_TYPE=postgres`, `MB_DB_HOST`, etc.). Redémarrage automatique (`restart: unless-stopped`).
- Les deux services communiquent via un réseau Docker interne. **N'expose PAS le port de Postgres vers l'extérieur** (sécurité).
- Lance la stack : `docker compose up -d`.
- Vérifie que les conteneurs tournent (`docker compose ps`) et suis les logs Metabase jusqu'à ce qu'il soit prêt (`docker compose logs -f metabase`). Le premier démarrage prend 1 à 2 minutes.

### 5. Accès et HTTPS
**Cas A — un domaine est fourni :**
- Installe un reverse proxy avec **HTTPS automatique**. Recommandation : **Caddy** (le plus simple, il gère les certificats Let's Encrypt tout seul). Ajoute-le comme service dans le compose, ou installe-le sur l'hôte, à ta convenance — explique ton choix.
- Configure-le pour rediriger `https://<domaine>` vers Metabase (port interne 3000).
- Vérifie que `https://<domaine>` répond bien et que le certificat est valide.

**Cas B — pas de domaine :**
- Assure-toi que Metabase est accessible sur `http://<IP>:3000`.
- Préviens-moi que la connexion est en HTTP non chiffré et qu'un domaine + HTTPS est recommandé si je mets des données sensibles.

### 6. Finalisation
- Donne-moi l'**URL finale** pour accéder à Metabase.
- Rappelle-moi qu'au premier accès, je devrai créer le compte administrateur dans l'interface web.
- Récapitule dans un petit mémo :
  - le contenu et l'emplacement du `docker-compose.yml`,
  - le mot de passe généré pour Postgres,
  - les commandes utiles : mettre à jour Metabase, redémarrer, voir les logs, sauvegarder la base.

### 7. Sauvegardes (bonus)
- Propose-moi un script simple de **sauvegarde de la base PostgreSQL** (dump régulier) et explique comment le programmer avec `cron`. Ne le mets en place que si je valide.

---

## Règles de conduite

1. **Une étape à la fois.** Ne balance pas 20 commandes d'un coup — avance, vérifie, puis continue.
2. **Explique** brièvement le "pourquoi" de chaque étape, pas seulement le "comment".
3. **Sécurité d'abord** : pare-feu, fail2ban, pas de port de base de données exposé, mots de passe forts.
4. **Rien d'irréversible sans me prévenir.** Si une commande efface des données ou change une config critique, décris-la et demande confirmation.
5. Si une commande échoue, **diagnostique la cause racine** avant de réessayer — pas de contournement bricolé.
6. À la fin, **teste réellement** que Metabase répond avant de me dire que c'est terminé.

Commence par te connecter au serveur et faire l'état des lieux (étape 1).
